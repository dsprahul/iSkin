SDA and SCL pins for this demo assume using Arduino Uno.

For python 2.7 run i2c_write_for_python2.py

For python 3.4.2 run i2c_write_for_python3.py

Use i2c_write_for_pythonX.py to run the program.